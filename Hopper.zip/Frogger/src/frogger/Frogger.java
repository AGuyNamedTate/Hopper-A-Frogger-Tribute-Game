/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frogger;



import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.util.Random;


/**
 *
 * @author TateM
 */
public class Frogger extends Canvas implements Runnable {

    /**
     * @param args the command line arguments
     */
    public static final int WIDTH = 640, HEIGHT = 640;
    
    private Thread thread;
    public static boolean running = false;
    
    private Random r = new Random();
    private BasicEnemy enemy;
    private Handler handler;
    private HUD hud;
    private int enemyHigh = 480 - 72;
    private int temp;
    private int enemyLong = 0;
    public int direct =1;
    
    public Frogger() {
        // initialize handler first
        handler = new Handler();
        //so the program knows to look for key input
        this.addKeyListener(new KeyInput(handler));
        
        new Window(WIDTH, HEIGHT, "Leps and Bons", this);
        
        hud = new HUD();
        
        
        //for (int i = 0; i < 50; i++) {

            //adding a second player
        //handler.addObject(new Player(160, 100, ID.Player2));
        //adding enemies in lanes(like a car should be)
        handler.addObject(new Bush(0, 0, ID.Bush));
        for (int i = 0; i < 3; i++) {
            
            setDirection(this.direct);
            handler.addObject(new Lane(0, enemyHigh, ID.Lane));
            int type = r.nextInt(3);
            for (int n = 0; n < 4; n++) {
                
                spawn(type); 
                enemyLong += 128;
            }
            
            enemyHigh = enemyHigh - 32;
            enemyLong = 0;
        }
        handler.addObject(new Player(304, HEIGHT - 31, ID.Player, handler));
        
        for (int i = 0; i < 3; i++) {
            handler.addObject(new BasicJoey(r.nextInt(19)*32, r.nextInt(18)*32, ID.Joey));            
        }
        
    }    
    
    public synchronized void start() {
        thread = new Thread((Runnable) this);
        thread.start();
        running = true;
    }
    
    public synchronized void stop() {
        try {
            thread.join();
            running = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //used for fps display. very important. Also makes game work and update
    public void run() {
        this.requestFocus();
        long lastTime = System.nanoTime();
        double amountOfTicks = 60.0;
        double ns = 100000000 / amountOfTicks;
        double delta = 0;
        long timer = System.currentTimeMillis();
        int frames = 0;
        while (running) {
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;
            while (delta >= 1) {
                tick();
                delta--;
            }
            if (running) {
                render();
            }
            frames++;
            if (System.currentTimeMillis() - timer > 1000) {
                timer += 1000;
                System.out.println("FPS: " + frames);
                
                frames = 0;
            }
        }
        stop();
    }
    
    private void tick() {
        handler.tick();
        hud.tick();
    }
    
    private void render() {
        BufferStrategy bs = this.getBufferStrategy();
        if (bs == null) {
            this.createBufferStrategy(3);
            return;
        }
        
        Graphics g = bs.getDrawGraphics();
        
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, WIDTH, HEIGHT);
        
        handler.render(g);
        
        hud.render(g);
        
        g.dispose();
        bs.show();
    }
    
    public static int clamp(int var, int min, int max) {
        if (var >= max) {
            return var = max;
        } else if (var <= min) {
            return var = min;
        } else {
            return var;
        }
    }

    public void spawn(int type){
        
        
        
        if (type == 1) {
            handler.addObject(new BasicEnemy(enemyLong, enemyHigh, ID.Enemy, 0.128f*getDirection()));
        } else if (type == 2) {
            handler.addObject(new BasicEnemy(enemyLong, enemyHigh, ID.Bus, 0.085f*getDirection()));
        } else {
            handler.addObject(new BasicEnemy(enemyLong, enemyHigh, ID.Bike, 0.2f*getDirection()));
        }
    }
    
    public void setDirection(int direct){
        this.direct = r.nextInt(2);
        if(this.direct==0){
            this.direct=-1;
        }
    }
    
    public int getDirection(){
        return this.direct;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        new Frogger();
        
    }
    
}
