package frogger;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author TateM
 */
public class HUD {

    public static int HEALTH = 100;

    public int greenVal = 255;

    public void tick() {

        HEALTH = Frogger.clamp(HEALTH, 0, 100);
        greenVal = Frogger.clamp(greenVal, 0, 255);
        greenVal = HEALTH * 2;
    }

    public void render(Graphics g) {
        g.setColor(Color.gray);
        g.fillRect(15, 15, 200, 32);
        g.setColor(new Color(100, greenVal, 0));
        g.fillRect(15, 15, HEALTH * 2, 32);
        g.drawRect(15, 15, 200, 32);

    }

}
