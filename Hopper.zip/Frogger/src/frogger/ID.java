package frogger;

/**
 *
 * @author TateM
 */
public enum ID {

    //for our id classes of same names

    Player(),
    Player2(),
    Enemy(),
    Joey(),
    Bus(),
    Bike(),
    Lane(),
    Bush(),
    Outback(),
    MudPit(),
    Log(),
    Grass(),
    Death(),
    Win();

}
