package frogger;

import frogger.ID;
import static frogger.ID.Player;
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import frogger.BasicEnemy;
import java.awt.Rectangle;
import javax.swing.ImageIcon;

/**
 *
 * @author TateM
 */
public class Player extends GameObject {

    //Player Player = new Player((int)x,(int)y,id.Player);
    //BasicEnemy Enemy = new BasicEnemy((int)x,(int)y,id.Enemy,0.28);
    Random r = new Random();
    Handler handler;

    private int bottom = 30;
    private int right = 30;
    public ImageIcon player = new ImageIcon(this.getClass().getResource("kangaroo1.PNG"));
    public ImageIcon playerAlt = new ImageIcon(this.getClass().getResource("kangaroo2.PNG"));



    BasicEnemy other;
    public int joeyCount = 0;

    public Player(int x, int y, ID id, Handler handler) {
        super(x, y, id);
        this.handler = handler;

    }

    //  @Override
    public void tick() {
        // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        //this is so my objects move
        x += velX;
        y += velY;

        x = Frogger.clamp((int) x, 0, Frogger.WIDTH - 38);
        y = Frogger.clamp((int) y, 0, Frogger.HEIGHT - 72);

        collision();
    }

    public void collision() {

        for (int i = 0; i < handler.object.size(); i++) {

            GameObject tempObject = handler.object.get(i);

            if (tempObject.getId() == ID.Enemy || tempObject.getId() == ID.Bus) {
                if (getBounds().intersects(tempObject.getBounds())) {

                    HUD.HEALTH = 0;
                    if (HUD.HEALTH <= 0) {
                    }
                }
            } else if (tempObject.getId() == ID.Bike) {
                if (getBounds().intersects(tempObject.getBounds())) {
                    HUD.HEALTH -= 25;
                    handler.removeObject(handler.object.get(i));

                    if (HUD.HEALTH <= 0) {
                    }
                }
            } else if (tempObject.getId() == ID.Joey) {
                if (getBounds().intersects(tempObject.getBounds())) {
                    if (this.joeyCount < 2) {
                        handler.removeObject(handler.object.get(i));
                        this.joeyCount++;
                        System.out.println("Joey Count: " +this.joeyCount);
                    }
                }
            }else if(tempObject.getId()==ID.Bush){
                if (getBounds().intersects(tempObject.getBounds())) {
                    joeyCount = 0;

                }
            }
        }
    }

    // @Override

    public void render(Graphics g) {
        // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        //for multiplayer use the if statement below
        if (id == ID.Player) {
            //my player and their color
            g.setColor(Color.white);
            //g.fillRect((int) x, (int) y, right, bottom);
            player.paintIcon(null, g,(int) x,(int) y);
        }/* else if (id == ID.Player2) {
         g.setColor(Color.blue);
         g.fillRect(x, y, 32, 32); 
         }*/

    }

    public Rectangle getBounds() {
        return new Rectangle((int) x, (int) y, 30, 32);
    }
}
